#include <mfl2.h>

#include <mfl1.h>

int f2()
{
  return f() * f();
}

std::string Hello2::g()
{
  return Hello().g() + Hello().g();
}
