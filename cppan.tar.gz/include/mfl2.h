#pragma once

#include <string>

CPPAN_EXPORT int f2();

struct CPPAN_EXPORT Hello2
{
  std::string g();
};
